fx_version 'cerulean'
lua54 'yes'
game 'gta5'

author 'Djawed the king en prxy'
description 'Redzone ;]'
version '1.0.1'

shared_scripts {
    '@es_extended/imports.lua',
    '@ox_lib/init.lua'
}

ui_page 'html/index.html'
files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    "html/imgs/*.png",
    'html/sounds/*.wav',
    'html/sounds/*.ogg',
    'html/sounds/*.flac',
    'html/sounds/**/*.ogg',
    'html/*.png'
}

client_scripts {
    '@PolyZone/client.lua',
    'config.lua',
    'client/main.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'config.lua',
    'server/loadouts.lua',
    'server/main.lua',
    'server/deathdrop.lua',
}

