var audioPlayer = null;

window.addEventListener("message", function (event) {
    if (event.data.action == "displaycounter") {
        let kills = event.data.kills;
        let players = event.data.players;

        $(".killcount, .playercount, .killcount input, .playercount input").css("display", "block");

        if (players !== undefined) {
            redzonecount = document.getElementById("redzonecounter");
            redzonecount.value = players;

            killcounter = document.getElementById("killcounter");
            killcounter.value = kills;
        }
    } else if (event.data.action == "displaystats") {
        let rank = event.data.rank;
        let points = event.data.points;
        let kd = event.data.kd;
        let kills = event.data.kills;
        let headshots = event.data.headshots;
        let deaths = event.data.deaths;
        let credits = event.data.credits;
        let clan = event.data.clan;

        $(".stats, .stats input").css("display", "inline");

        rankshow = document.getElementById("rank");
        rankshow.value = rank;

        pointscount = document.getElementById("points");
        pointscount.value = points;

        kdcounter = document.getElementById("kdr");
        kdcounter.value = kd;

        killcounter = document.getElementById("kills");
        killcounter.value = kills;

        deathscounter = document.getElementById("deaths");
        deathscounter.value = deaths;

        creditscount = document.getElementById("credits");
        creditscount.value = credits;

        // headshotscounter = document.getElementById("headshots");
        // headshotscounter.value = headshots;

        // clanboard = document.getElementById("clan");
        // clanboard.value = clan;
    } else if (event.data.action == "hidestats") {
        $(".stats").css("display", "none");
    } else if (event.data.action == "hidecounter") {
        $(".killcount, .playercount, .killcount input, .playercount input").css("display", "none");
    } else if (event.data.action == "hide") {
        $(".stats, .killcount, .playercount, .killcount input, .playercount input").css("display", "none");
    } else if (event.data.transactionType == "playSound") {
        if (audioPlayer != null) {
            audioPlayer.pause();
        }
        audioPlayer = new Howl({ src: ["./sounds/" + event.data.transactionFile], volume: event.data.transactionVolume });
        audioPlayer.play();
    } else if (event.data.action == "redzonemenu") {
        $(".custom-ui").fadeIn();
        $('.custom-ui').css('opacity', '0');
    }
});

document.addEventListener('DOMContentLoaded', function () {
    var redzonemenu = document.querySelector('.custom-ui');
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            redzonemenu.style.display = 'none';
        }
    });
});

function PlayRedzone() {
    $.post(`https://${GetCurrentResourceName()}/PlayRedzone`, JSON.stringify({}));
}

function CloseRedzone() {
    $(".custom-ui").css("display", "none");
    $.post(`https://${GetCurrentResourceName()}/CloseRedzoneMenu`, JSON.stringify({}));
}