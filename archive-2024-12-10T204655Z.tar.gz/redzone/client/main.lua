ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(100)
    end
end)

local isinderedzone = false
local isloadinginredzone = false
local isdichtbijderedzone = false
local playercount = 0
local kills = 0
local currentmap = 0
local mapswitch = false

local AllKills = 0
local AllDeaths = 0
local AllHeadshots = 0
local AllPoints = 0
local AllKD = '0.0'
local Credits = 0
local Clan = 0
local Rank = 'Unranked'

Citizen.CreateThread(function()
    currentmap = lib.callback.await('redzone:get:currentmap')

    LoadStats()
end)

RegisterNetEvent('wave:redzone:add:components', function(weapon, components)
    for i = 1, #components do
        print(components[i])
        local success = lib.callback.await('ox_inventory:updateWeapon', false, 'component', 1)

        if success then
           print('success')
           TriggerEvent('ox_inventory:updateWeaponComponent', 'added', GetHashKey(weapon), components[i])
           GiveWeaponComponentToPed(PlayerPedId(), GetHashKey(weapon), GetHashKey(components[i]))
        else
            print('not success')
        end
    end
end)

local function currentMap()
    local currentMap = lib.callback.await('redzone:get:currentmap')
    
    if currentMap then
        local groupIndex = currentMap.groupIndex
        local location = currentMap.location
        
        if location then
            -- print("Huidige redzone groep index: " .. groupIndex)
            -- print("Huidige redzone locatie: x=" .. location.x .. ", y=" .. location.y .. ", z=" .. location.z)
        else
            -- print("Geen geldige redzone locatie gevonden.")
        end
    else
        -- print("Kon de huidige redzone niet ophalen.")
    end
end

currentMap()

-- Blips
Citizen.CreateThread(function()
    if Config.Blip then
        local blip = AddBlipForCoord(Config.RedzoneLocatie)
        SetBlipSprite(blip, 303)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, 0.8)
        SetBlipColour(blip, 1)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Redzone")
        EndTextCommandSetBlipName(blip)
    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(playerData)
    PlayerData = playerData
    isPlayerLoaded = true
end)


Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end

    while true do
        Citizen.Wait(0)          
        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)
        local dist = #(coords - Config.RedzoneLocatie)

        if isinderedzone then
            Citizen.Wait(500)
            goto continue
        end
        if dist <= 20.0 and dist > 3.0 then
            ESX.DrawBasicMarker(Config.RedzoneLocatie, 0, 74, 154)
            isdichtbijderedzone = true
            LoadStats()
        elseif dist < 3.0 then
            exports['frp-interaction']:Interaction({ r = '0', g = '74', b = '154' }, '[E] - Betreed Redzone',
                Config.RedzoneLocatie, 2.5, GetCurrentResourceName() .. '-action-enterredzone')
            ESX.DrawBasicMarker(Config.RedzoneLocatie, 0, 74, 154)
            isdichtbijderedzone = true
            LoadStats()
            if IsControlJustReleased(0, 38) then
                currentMap = lib.callback.await('redzone:get:currentmap')
                local delay = 10  -- Hier stel je de vaste vertraging in, bijvoorbeeld 10 seconden
                ESX.ShowNotification('success', 'Je wordt over ' .. delay .. ' secondes naar de redzone gestuurd.', 3000)
                isloadinginredzone = true

                while delay > 0 do
                    DebugPrint(delay)
                    delay = delay - 1
                    Citizen.Wait(1000)
                    
                    if delay < 5 then
                        DoScreenFadeOut(3000)
                    end
                end
                isloadinginredzone = false
                kills = 0
                TeleportNaarRedzone()
            end
        else
            isdichtbijderedzone = false
            LoadStats()
        end

        ::continue::
    end
end)



function EnterRedzone()
    currentmap = lib.callback.await('redzone:get:currentmap')
    local delay = HaaldelayOp()
    ESX.ShowNotification('success', 'Je wordt over ' .. delay .. ' secondes naar de redzone gestuurd.', 3000)
    isloadinginredzone = true
    while delay > 0 do
        DebugPrint(delay)
        delay = delay - 1
        Citizen.Wait(1000)
        if delay < 5 then
            DoScreenFadeOut(3000)
        end
    end
    isloadinginredzone = false
    TeleportNaarRedzone()
end

local isloadingredzone = false

function TeleportNaarRedzone()
    TriggerServerEvent('redzone:join', GetPlayerServerId(PlayerId()))
    SetPedArmour(GetPlayerPed(-1), 0)
    kills = 0
    SetEntityHealth(PlayerPedId(), 200)
    TriggerServerEvent('inredzonewereld')
    ZetPlayerInWereld('redzone')
    DebugPrint('betreden van de redzone!')
    SetCurrentPedWeapon(PlayerPedId(), GetHashKey("WEAPON_UNARMED"), true)
    isinderedzone = true
    TriggerEvent('frp-hud:togglehud', false)
    TriggerServerEvent("saveloadout", loadout)
    Wait(1000)
    MaakRedzoneLoadout()
    SpawnProt('start')
    PlayCustomSound("game_start/voice_encourage_start_" .. math.random(1, 16) .. ".ogg", 0.08)
    GetStats()
    Citizen.Wait(1000)
    TriggerEvent('redzone:zetcompassaan')
    ESX.UI.Menu.CloseAll()
    GameEnter = true
    DoScreenFadeIn(5000) 
    spawnblockade = true
    isDead = false
    SpawnProt('stop')
end

local function TeleportNaarSpawn()
   -- local respawnDelay = HaaldelayOp()  
    

    if type(respawnDelay) ~= "number" then
   --     respawnDelay = HaaldelayOp() 
    end

    if type(respawnDelay) ~= "number" then
        respawnDelay = 10 
    end



    ESX.ShowNotification('info', 'Je wordt naar de lobby geteleporteerd.', 3000)

    while respawnDelay > 0 do
        Citizen.Wait(1000)
        respawnDelay = respawnDelay - 1
    end

    local respawnLocation = Config.TpLocatie
    if ESX and ESX.Game then
        ESX.Game.Teleport(PlayerPedId(), respawnLocation)
    end
    TriggerEvent('redzone:GameLeave')
    isinderedzone = false
    isloadinginredzone = false
    TriggerServerEvent('uitredzonewereld')
    ZetPlayerInWereld('spawn')
    TriggerEvent('redzone:zetcompassuit')
    LocalPlayer.state.invBusy = false
    TriggerEvent('frp-ambulance:client:revive:player')
    TriggerServerEvent('frp-ambulance:server:set:death:status', false)
    TriggerEvent('frp-hud:togglehud', false)
    TriggerServerEvent("saveloadout", loadout)
    isRespawning = false
    isPlayerDead = false
    DoScreenFadeIn(1000)
end

function ZetPlayerInWereld(wereld)
    ESX.TriggerServerCallback('redzone:set:wereld', function(success)
        if success then
            DebugPrint('Player set in world: ' .. wereld)
        else
            DebugPrint('Failed to set player in world: ' .. wereld)
        end
    end, wereld)
end


-- // [newmap] \\ --

RegisterNetEvent('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
    isPlayerLoaded = true
end)

RegisterNetEvent('redzone:switch:to:newmap')
AddEventHandler('redzone:switch:to:newmap', function(mapid)
    local playerId = PlayerId()

    if isinderedzone then
        mapswitch = true
        currentMap = mapid
        
        TriggerEvent('chatMessage', 'Redzone', "adminchat", 'De map veranderd naar: ' .. Config.MapLabels[currentMap])
        
        local mapdelay = 10
        ESX.ShowNotification('info', 'Je wordt over ' .. mapdelay .. ' secondes naar de nieuwe map geteleporteerd.')
        
        isloadinginredzone = true
        while mapdelay > 0 do
            Citizen.Wait(1000)
            if mapdelay < 5 then
                DoScreenFadeOut(3000)
            end
            mapdelay = mapdelay - 1
        end        
        mapswitch = false
        isloadinginredzone = false        
        TriggerEvent('frp-ambulance:client:revive:player')

        TeleportNaarRedzone(mapid)
    else
        ESX.ShowNotification('Je bent momenteel niet in de redzone.')
    end
end)

-- DebugPrint
function DebugPrint(...)
    if Config.DebugMode then
        print(...)
    end
end

-- Killmessage
RegisterNetEvent('redzone:sendkillmessage')
AddEventHandler('redzone:sendkillmessage', function(type, name, attacker, distance, killerid)
    if isinderedzone == true or isdichtbijderedzone == true then
        if type == 0 then
            TriggerEvent('chatMessage', 'Redzone', "adminchat",
                name .. ' is gekilled door ' .. attacker .. ' van ' .. distance .. 'm afstand')
        elseif type == 1 then
            TriggerEvent('chatMessage', 'Redzone', "adminchat", name .. ' heeft zelfmoord gepleegd')
        end
    end
end)

RegisterNetEvent('redzone:player:death:sound')
AddEventHandler('redzone:player:death:sound', function()
    PlayCustomSound("player_death/male/player_death_" .. math.random(1, 11) .. ".ogg", 0.08)
end)

RegisterNetEvent('redzone:player:kill:sound')
AddEventHandler('redzone:player:kill:sound', function()
    PlayCustomSound("player_kill/male/normal_kill_" .. math.random(1, 11) .. ".ogg", 0.08)
end)


-- HITMARKERS
local hitmarkersound = true
RegisterNetEvent("gameEventTriggered")
AddEventHandler("gameEventTriggered", function(name, args)
    if name == "CEventNetworkEntityDamage" then
        local entity, destroyer, _, isFatal, weapon_old, weapon_old2, weapon = table.unpack(args)
        local PlayerPedId = PlayerPedId()
        local _niks, lastdamagebone = GetPedLastDamageBone(entity)
        if destroyer == PlayerPedId then
            local isped = IsEntityAPed(entity)
            if isped == false then
                return
            end
            if entity == PlayerPedId then
                return
            end
            if hitmarkersound and isinderedzone then
                TriggerEvent("redzone:hitmarker")
                if tonumber(lastdamagebone) == 31086 then
                    PlayCustomSound("headshot.ogg", 0.10)
                else
                    PlayCustomSound("game_hitmarker.ogg", 0.7)
                end
            end
        end
    end
end)

RegisterNetEvent("redzone:playcustomsound", function(sound, volume)
    PlayCustomSound(sound, volume)
end)

function PlayCustomSound(soundFile, soundVolume)
    SendNUIMessage({
        transactionType = 'playSound',
        transactionFile = soundFile,
        transactionVolume = soundVolume,
    })
end

Citizen.CreateThread(function()
    Wait(10000)
    LoadStreamDict("icon")
end)

-- AutoMessage
local automatischeberichtenredzone = Config.AutoMessages
if Config.AutoMessage then
    Citizen.CreateThread(function()
        while true do
            Wait(0)
            if isinderedzone == true or isdichtbijderedzone == true then
                for i in pairs(automatischeberichtenredzone) do
                    randomnumber = math.random(1, #automatischeberichtenredzone)
                    if i == randomnumber then
                        if isinderedzone == true or isdichtbijderedzone == true then
                            TriggerEvent('chatMessage', 'Redzone AutoMessage', "automessage",
                                automatischeberichtenredzone[i])
                            Citizen.Wait(5 * 60 * 1000)
                        end
                    end
                end
            else
                Wait(5000)
            end
        end
    end)
end

-- Killmessage
RegisterNetEvent('redzone:sendkillmessage')
AddEventHandler('redzone:sendkillmessage', function(type, name, attacker, distance, killerid)
    if isinderedzone == true or isdichtbijderedzone == true then
        if type == 0 then
            TriggerEvent('chatMessage', 'Redzone', "adminchat",
                name .. ' is gekilled door ' .. attacker .. ' van ' .. distance .. 'm afstand')
        elseif type == 1 then
            TriggerEvent('chatMessage', 'Redzone', "adminchat", name .. ' heeft zelfmoord gepleegd')
        end
    end
end)

---@param ms number
---@param cb function
function RealWait(ms, cb)
    local timer = GetGameTimer() + ms
    while GetGameTimer() < timer do
        if cb ~= nil then
            cb(function(stop)
                if stop then
                    timer = 0
                    return
                end
            end)
        end
        Wait(0)
    end
end

---@param dict string
function LoadStreamDict(dict)
    while not HasStreamedTextureDictLoaded(dict) do
        RequestStreamedTextureDict(dict, 1)

        Wait(500)
    end
    RealWait(50)
end

---@param x number
---@param y number
---@return number, number
function ConvertToPixel(x, y)
    return (x / 1920), (y / 1080)
end

RegisterNetEvent("redzone:hitmarker", function()
    while not HasStreamedTextureDictLoaded("icon") do
        RequestStreamedTextureDict("icon", 1)

        Wait(100)
    end
    Citizen.CreateThread(function()
        local i = 0
        local x, y = ConvertToPixel(64, 64)
        while i < 10 do
            DrawSprite("icon", "damage_feedback", 0.5, 0.5, x / 2, y / 2, 0, 255, 255, 255, 255)
            i = i + 1
            Wait(0)
        end
    end)
end)

-- Reload sound
local reloadsoundcooldown = false
RegisterNetEvent("redzone:onplayerreload", function()
    if isinderedzone and not reloadsoundcooldown then
        PlayCustomSound("player_reloading/male/player_reloading_" .. math.random(1, 7) .. ".ogg", 0.08)

        reloadsoundcooldown = true
        Citizen.CreateThread(function()
            Wait(2500)
            reloadsoundcooldown = false
        end)
    end
end)

local reloading = false
Citizen.CreateThread(function()
    local ped = PlayerPedId()
    while true do
        while not isinderedzone do Wait(1000) end
        if IsPedReloading(ped) then
            if reloading == false then
                reloading = true
                TriggerEvent("redzone:onplayerreload")
            end
        else
            reloading = false
        end
        Wait(100)
    end
end)


-- Spawn Wapen in
---@param weapon string
---@param ammo number
---@param randomitem string
---@param components table
function MaakRedzoneLoadout()
    local playerPed = PlayerPedId()
    TriggerServerEvent("redzone:geefwapen")
end

-- Voorbeeld van debug functie om af te drukken naar de console
function DebugPrint(...)
    print(...)
end



---@param type string
function SpawnProt(type)
    if type == 'start' then
        DebugPrint('SpawnProtection = true')
        SetEntityAlpha(PlayerPedId(), 200, 0)
        SetLocalPlayerAsGhost(true)
    elseif type == 'stop' then
        DebugPrint('SpawnProtection = false')
        ResetEntityAlpha(PlayerPedId())
        SetLocalPlayerAsGhost(false)
    end
end


-- Stim
exports('useStim', function(data, slot)
    local playerPed = PlayerPedId()
    local maxHealth = GetEntityMaxHealth(playerPed)
    local health = GetEntityHealth(playerPed)
    if not isinderedzone then       
        ESX.ShowNotification('info', 'Je kan dit alleen in de redzone gebruken!')
        return
    end
    if health < maxHealth then
        exports.ox_inventory:useItem(data, function(success)
            if success then
                local hpNodig = maxHealth - health
                local healed = 0
                Citizen.CreateThread(function()
                    while healed < hpNodig do
                        health = health + 5
                        SetEntityHealth(playerPed, health)
                        DebugPrint(healed)
                        Citizen.Wait(1000)
                        healed = healed + 5
                    end
                    ESX.ShowNotification('success', 'Je voelt je iets beter')
                end)
            end
        end)
    else
        ESX.ShowNotification('success', 'Je hebt geen stim nodig!')
    end
end)

-- Armor Plate
exports('useArmor', function(data, slot)
    local playerPed = PlayerPedId()
    local armor = GetPedArmour(playerPed)
    local newArmor = armor + 33
    if not isinderedzone then       
        ESX.ShowNotification('info', 'Je kan dit alleen in de redzone gebruken!')
        return
    end
    if 99 >= newArmor then
        exports.ox_inventory:useItem(data, function(success)
            if success then
                if 99 >= newArmor then
                    AddArmourToPed(playerPed, 33)
                    ESX.ShowNotification('success', 'Je hebt 1x Armor Plate gebruikt!')
                end
            end
        end)
    else
        ESX.ShowNotification('info', 'Je hebt geen armor plate nodig!')
    end
end)

-- Respawn
local ganaardelobby = false


function HaaldelayOp()
    local delay = 10 
    return delay
end

AddEventHandler('esx:onPlayerDeath', function(data)
    DebugPrint(json.encode(data))
    
    if isinderedzone then
        DebugPrint('Died in redzone')
        
        if not isloadinginredzone then
            local delay = HaaldelayOp() 
            ESX.ShowNotification('success', 'Je wordt over '.. delay ..' secondes naar de redzone gestuurd.', 3000)
            isloadinginredzone = true
            GetStats()

            Citizen.CreateThread(function()
                while delay > 0 do
                    Citizen.Wait(0)
                    
                    if not ganaardelobby then
                        drawTxt(0.91, 1.44, 1.0, 1.0, 0.6, "~r~DRUK OP [E] OM DE REDZONE TE LEAVEN", 255, 255, 255, 255)
                        
                        if IsControlJustReleased(0, 38) then
                            ESX.ShowNotification('success', 'Je wordt naar de lobby geteleporteerd.', 3000)
                            ganaardelobby = true
                        end
                    else
                        drawTxt(0.91, 1.44, 1.0, 1.0, 0.6, "~r~JE WORDT TERUG NAAR DE LOBBY GETELEPORTEERD", 255, 255, 255, 255)
                    end
                end
            end)

            while delay > 0 do
                DebugPrint(delay)
                Citizen.Wait(1000)
                
                delay = delay - 1
                if delay < 5 then
                    DoScreenFadeOut(3000)
                end
            end

            if ganaardelobby then
                TeleportNaarSpawn() 
                ganaardelobby = false 
            else
                TriggerEvent('frp-ambulance:client:revive:player')
                TeleportNaarRedzone()
            end
            

            isloadinginredzone = false
        end
    end
end)


---@param x number
---@param y number
---@param width number
---@param height number
---@param scale number
---@param text string
---@param r number
---@param g number
---@param b number
---@param a number
---@param outline boolean
function drawTxt(x, y, width, height, scale, text, r, g, b, a, outline)
    SetTextFont(4)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0, 255)
    SetTextEdge(2, 0, 0, 0, 255)
    SetTextDropShadow()
    SetTextOutline()
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x - width / 2, y - height / 2 + 0.005)
end


-- Tp naar redzone
RegisterCommand('redzone', function()
    if not isinderedzone then
        local ped = GetPlayerPed(-1)
        ESX.Game.Teleport(ped, Config.TpLocatie, function()
            ESX.ShowNotification('success', 'Je bent naar de redzone geteleporteerd!', 5000)
        end)
    else
        ESX.ShowNotification('warning', 'Je kan niet in de redzone naar de redzone teleporteren!', 5000)
    end
end, false)

TriggerEvent('chat:addSuggestion', '/redzone', 'Teleporteer naar de redzone')

-- Polyzone
local rzscrapeyard = PolyZone:Create({
    vector2(-399.46575927734, -1675.4169921875),
    vector2(-428.56692504882, -1754.1444091796),
    vector2(-434.04327392578, -1758.0528564454),
    vector2(-475.08798217774, -1768.5263671875),
    vector2(-496.34545898438, -1766.3588867188),
    vector2(-505.03503417968, -1764.0637207032),
    vector2(-514.78564453125, -1761.4985351562),
    vector2(-614.88580322266, -1689.9356689454),
    vector2(-629.76873779296, -1677.057006836),
    vector2(-605.63763427734, -1635.7209472656),
    vector2(-557.06866455078, -1632.2451171875),
    vector2(-556.3296508789, -1625.894897461),
    vector2(-555.58807373046, -1623.7287597656),
    vector2(-549.74609375, -1624.332397461),
    vector2(-547.6640625, -1600.7598876954),
    vector2(-477.55358886718, -1639.8897705078),
    vector2(-479.25939941406, -1643.0845947266),
    vector2(-461.53649902344, -1651.4924316406),
    vector2(-462.44244384766, -1653.5612792968)
}, {
    name = "scrape",
    --minZ = 18.792560577392,
    --maxZ = 29.46348953247
})

local rzcayoperico = PolyZone:Create({
    vector2(5020.1474609375, -5675.1142578125),
    vector2(4991.7197265625, -5707.3344726562),
    vector2(4987.9985351562, -5703.7919921875),
    vector2(4974.2705078125, -5719.0737304688),
    vector2(4969.833984375, -5716.2587890625),
    vector2(4953.642578125, -5747.8334960938),
    vector2(4961.4497070312, -5752.9755859375),
    vector2(4959.0493164062, -5760.876953125),
    vector2(4959.8090820312, -5768.6264648438),
    vector2(4959.8725585938, -5775.6396484375),
    vector2(4959.8212890625, -5782.9965820312),
    vector2(4956.568359375, -5790.94921875),
    vector2(4966.4482421875, -5796.6494140625),
    vector2(4996.4721679688, -5810.1616210938),
    vector2(4999.7368164062, -5805.123046875),
    vector2(5013.7846679688, -5816.2631835938),
    vector2(5025.0302734375, -5810.8735351562),
    vector2(5039.5961914062, -5802.4672851562),
    vector2(5054.8227539062, -5795.1845703125),
    vector2(5062.7084960938, -5792.109375),
    vector2(5079.689453125, -5775.6606445312),
    vector2(5102.02734375, -5749.2954101562),
    vector2(5086.5629882812, -5737.068359375),
    vector2(5088.3569335938, -5734.658203125),
    vector2(5079.8344726562, -5727.9545898438),
    vector2(5078.6357421875, -5730.1494140625),
    vector2(5072.5463867188, -5725.5473632812),
    vector2(5077.7001953125, -5718.8168945312),
    vector2(5072.15234375, -5712.6782226562),
    vector2(5052.9096679688, -5692.927734375),
    vector2(5045.5859375, -5697.6201171875),
    vector2(5035.5146484375, -5686.4174804688)
}, {
    name = "rzcayoperico",
    --minZ = 14.359112739562,
    --maxZ = 20.911867141724
})

local rzkortzcenter = PolyZone:Create({
    vector2(-2251.8715820312, 415.6176147461),
    vector2(-2270.6257324218, 407.14602661132),
    vector2(-2292.3413085938, 426.78482055664),
    vector2(-2323.455078125, 430.2790222168),
    vector2(-2325.7990722656, 408.47003173828),
    vector2(-2330.6296386718, 395.59924316406),
    vector2(-2359.33203125, 382.7183227539),
    vector2(-2331.4233398438, 319.4765625),
    vector2(-2368.4951171875, 302.11782836914),
    vector2(-2370.8151855468, 295.20458984375),
    vector2(-2340.8522949218, 228.52380371094),
    vector2(-2286.6079101562, 251.98046875),
    vector2(-2278.8449707032, 234.96946716308),
    vector2(-2278.8703613282, 215.22932434082),
    vector2(-2255.3095703125, 160.46290588378),
    vector2(-2173.3308105468, 196.50552368164),
    vector2(-2171.4821777344, 199.9778289795),
    vector2(-2170.775390625, 206.00595092774),
    vector2(-2153.0183105468, 215.89083862304),
    vector2(-2148.5380859375, 219.008102417),
    vector2(-2146.2880859375, 222.69854736328),
    vector2(-2146.2294921875, 229.7215423584),
    vector2(-2148.0551757812, 233.08973693848),
    vector2(-2151.0524902344, 237.3903503418),
    vector2(-2152.8986816406, 243.75576782226),
    vector2(-2154.7497558594, 250.63084411622),
    vector2(-2167.1376953125, 258.53689575196)
}, {
    name = "rzkortzcenter",
    --minZ = 170.3469543457,
    --maxZ = 191.60653686524
})

local rzmirrorpark = PolyZone:Create({
    vector2(856.50689697266, -545.4130859375),
    vector2(886.37164306641, -590.13391113281),
    vector2(964.69372558594, -659.53601074219),
    vector2(990.0595703125, -667.90692138672),
    vector2(1023.5385131836, -645.64440917969),
    vector2(1191.4449462891, -523.66076660156),
    vector2(1273.9591064453, -559.36724853516),
    vector2(1323.921875, -411.41729736328),
    vector2(1226.1904296875, -363.62713623047),
    vector2(1133.7589111328, -348.98849487305),
    vector2(1096.0972900391, -366.14199829102),
}, {
    name = "rzmirrorpark",
    --minZ = 69.43000793457,
    --maxZ = 88.530212402344
})

local rzhouthakkers = PolyZone:Create({
    vector2(-500.22348022461, 5227.9057617188),
    vector2(-560.16015625, 5254.4765625),
    vector2(-568.62915039063, 5235.6435546875),
    vector2(-590.5146484375, 5244.4287109375),
    vector2(-580.00415039063, 5263.2758789063),
    vector2(-607.13500976563, 5291.1596679688),
    vector2(-607.38928222656, 5368.1186523438),
    vector2(-539.62426757813, 5396.638671875),
    vector2(-457.98736572266, 5388.103515625),
    vector2(-459.70095825195, 5341.4951171875),
}, {
    name = "rzhouthakkers",
    --minZ = 69.43000793457,
    --maxZ = 88.530212402344
})

local rzgrovestreet = PolyZone:Create({
    vector2(152.11085510254, -1776.3881835938),
    vector2(252.38586425781, -1847.1619873047),
    vector2(299.76483154297, -1856.8909912109),
    vector2(389.95556640625, -1755.6781005859),
    vector2(475.70077514648, -1827.4135742188),
    vector2(238.16546630859, -2075.7866210938),
    vector2(94.285598754883, -2028.3103027344),
    vector2(88.486679077148, -1992.5616455078),
    vector2(20.099857330322, -1923.615234375),
    vector2(20.099857330322, -1923.615234375),
    vector2(20.595176696777, -1919.8255615234),
    vector2(-1.9003067016602, -1898.2429199219),
    vector2(-51.514743804932, -1859.2416992188),
    vector2(-51.68062210083, -1824.5942382813),
    vector2(-10.327481269836, -1774.4934082031),
    vector2(22.132616043091, -1778.7730712891),
    vector2(85.579734802246, -1830.9230957031),
    vector2(98.949882507324, -1815.5361328125),
    vector2(93.560989379883, -1811.19140625),
    vector2(121.64582824707, -1813.3227539063),
}, {
    name = "rzgrovestreet",
    --minZ = 69.43000793457,
    --maxZ = 88.530212402344
})

local paleto = PolyZone:Create({
    vector2(134.1771850586, 6531.3999023438),
    vector2(-370.43469238282, 6016.1484375),
    vector2(-427.27407836914, 6072.80078125),
    vector2(-424.80532836914, 6093.8452148438),
    vector2(-375.37170410156, 6148.8505859375),
    vector2(-419.94491577148, 6195.2841796875),
    vector2(-420.50518798828, 6214.0263671875),
    vector2(-416.52548217774, 6265.8432617188),
    vector2(-373.12435913086, 6311.9350585938),
    vector2(-315.35284423828, 6362.0219726562),
    vector2(-233.21453857422, 6414.9038085938),
    vector2(-193.27290344238, 6463.91015625),
    vector2(-112.67630767822, 6564.1499023438),
    vector2(-24.09422302246, 6633.9409179688),
    vector2(33.35160446167, 6651.5517578125),
    vector2(72.29997253418, 6621.5034179688),
    vector2(148.1143951416, 6545.4633789062)
}, {
    name = "paleto",
    --minZ = 29.480167388916,
    --maxZ = 31.77783203125
})

local sandy = PolyZone:Create({
    vector2(2027.0056152344, 3769.1557617188),
    vector2(1588.134399414, 3515.43359375),
    vector2(1483.0698242188, 3713.9970703125),
    vector2(1735.2099609375, 3910.4243164062),
    vector2(1868.9118652344, 3941.3444824218),
    vector2(1910.2561035156, 3938.4772949218),
    vector2(1945.586303711, 3911.3032226562),
    vector2(1998.7844238282, 3819.1740722656)
}, {
    name = "sandy",
    --minZ = 32.242443084716,
    --maxZ = 36.200763702392
})

local humanelabs = PolyZone:Create({
    vector2(3429.6540527344, 3772.8703613282),
    vector2(3456.3940429688, 3784.390625),
    vector2(3464.0695800782, 3801.234375),
    vector2(3479.1020507812, 3813.6430664062),
    vector2(3502.1730957032, 3820.5393066406),
    vector2(3587.3068847656, 3818.2763671875),
    vector2(3609.4538574218, 3815.8864746094),
    vector2(3626.8515625, 3802.4470214844),
    vector2(3640.4975585938, 3782.013671875),
    vector2(3647.8547363282, 3761.4013671875),
    vector2(3644.08203125, 3736.8459472656),
    vector2(3650.3283691406, 3731.6550292968),
    vector2(3650.26171875, 3729.3864746094),
    vector2(3614.7644042968, 3693.4616699218),
    vector2(3607.7807617188, 3652.8879394532),
    vector2(3619.7175292968, 3649.154296875),
    vector2(3609.662109375, 3596.990234375),
    vector2(3584.9069824218, 3601.2907714844),
    vector2(3586.6325683594, 3608.8032226562),
    vector2(3404.8776855468, 3642.7414550782),
    vector2(3410.8999023438, 3677.4306640625),
    vector2(3431.7502441406, 3748.6967773438),
    vector2(3440.0510253906, 3754.0185546875)
}, {
    name = "humanelabs",
    --minZ = 28.541831970214,
    --maxZ = 42.365531921386
})

local powerplant = PolyZone:Create({
    vector2(2766.1279296875, 1325.8841552734),
    vector2(2671.0231933594, 1325.88671875),
    vector2(2669.98828125, 1343.8934326172),
    vector2(2646.2431640625, 1343.6906738282),
    vector2(2648.4599609375, 1727.0437011718),
    vector2(2840.4282226562, 1726.1018066406),
    vector2(2840.5686035156, 1618.4958496094),
    vector2(2849.3693847656, 1602.6110839844),
    vector2(2844.8852539062, 1585.5670166016),
    vector2(2884.0119628906, 1575.2452392578),
    vector2(2885.5122070312, 1532.6511230468),
    vector2(2893.9877929688, 1529.8713378906),
    vector2(2888.6005859375, 1509.3330078125),
    vector2(2879.865234375, 1510.7843017578),
    vector2(2856.5822753906, 1425.1477050782),
    vector2(2810.3752441406, 1435.7155761718),
    vector2(2797.384765625, 1385.7170410156),
    vector2(2765.9030761718, 1385.1072998046)
}, {
    name = "powerplant",
    --minZ = 21.140827178956,
    --maxZ = 26.742401123046
})

local hotel = PolyZone:Create({
    vector2(-1407.2780761718, 323.72610473632),
    vector2(-1388.384765625, 348.49935913086),
    vector2(-1365.3253173828, 365.34875488282),
    vector2(-1314.2923583984, 383.72012329102),
    vector2(-1231.2060546875, 390.5528869629),
    vector2(-1230.9056396484, 388.75582885742),
    vector2(-1220.4805908204, 391.64169311524),
    vector2(-1214.6899414062, 387.70446777344),
    vector2(-1208.8347167968, 366.86376953125),
    vector2(-1217.798461914, 354.77645874024),
    vector2(-1209.244506836, 325.1869506836),
    vector2(-1210.6442871094, 323.53536987304),
    vector2(-1220.4141845704, 320.53060913086),
    vector2(-1217.7612304688, 309.7560119629),
    vector2(-1221.3983154296, 308.53149414062),
    vector2(-1221.374633789, 305.82971191406),
    vector2(-1223.3074951172, 305.16592407226),
    vector2(-1220.683959961, 292.99142456054),
    vector2(-1228.3081054688, 289.35458374024),
    vector2(-1224.3833007812, 273.00479125976),
    vector2(-1236.7785644532, 270.08312988282),
    vector2(-1237.951171875, 272.7677307129),
    vector2(-1253.314819336, 267.14315795898),
    vector2(-1253.4304199218, 247.10963439942),
    vector2(-1274.1403808594, 242.3821105957),
    vector2(-1295.9538574218, 239.87188720704),
    vector2(-1309.0299072266, 238.90762329102),
    vector2(-1329.4114990234, 237.59175109864),
    vector2(-1344.4620361328, 236.4649963379),
    vector2(-1375.5509033204, 228.52432250976),
    vector2(-1384.015258789, 244.88037109375),
    vector2(-1392.1746826172, 244.18995666504),
    vector2(-1398.279296875, 248.94836425782),
    vector2(-1400.1219482422, 259.41040039062),
    vector2(-1403.9645996094, 258.28454589844),
    vector2(-1416.2373046875, 296.93588256836),
    vector2(-1413.20703125, 297.74029541016),
    vector2(-1415.50390625, 304.28561401368),
    vector2(-1413.3637695312, 314.4048461914),
    vector2(-1409.8006591796, 322.59106445312)
}, {
    name = "hotel",
    --minZ = 58.693519592286,
    --maxZ = 80.520347595214
})

local hb = PolyZone:Create({
    vector2(-517.6552734375, -1058.2039794922),
    vector2(-524.73791503906, -978.56024169922),
    vector2(-521.02880859375, -955.74896240234),
    vector2(-497.40826416016, -912.19506835938),
    vector2(-495.89553833008, -907.11303710938),
    vector2(-492.52642822266, -898.20788574218),
    vector2(-486.43786621094, -887.53039550782),
    vector2(-483.7338256836, -879.13623046875),
    vector2(-482.65322875976, -867.2435913086),
    vector2(-482.8189086914, -854.6713256836),
    vector2(-438.66494750976, -855.70739746094),
    vector2(-437.5266418457, -946.37109375),
    vector2(-431.74822998046, -1004.0169677734),
    vector2(-431.59371948242, -1024.3406982422),
    vector2(-432.30157470704, -1037.4445800782),
    vector2(-434.42184448242, -1052.8328857422),
    vector2(-441.84274291992, -1092.5653076172),
    vector2(-443.95385742188, -1092.3598632812),
    vector2(-471.54342651368, -1082.5267333984),
    vector2(-487.42929077148, -1075.5871582032)
}, {
    name = "hb",
    --minZ = 22.692295074462,
    --maxZ = 41.83897781372
})

local strand = PolyZone:Create({
    vector2(-1151.7076416016, -1213.720336914),
    vector2(-1189.4050292968, -1226.1278076172),
    vector2(-1190.07421875, -1221.8552246094),
    vector2(-1189.0989990234, -1217.7155761718),
    vector2(-1192.1511230468, -1204.9750976562),
    vector2(-1266.1075439454, -1224.61328125),
    vector2(-1297.9107666016, -1240.9379882812),
    vector2(-1362.6951904296, -1265.377319336),
    vector2(-1534.5168457032, -1326.616821289),
    vector2(-1509.3116455078, -1445.079711914),
    vector2(-1517.5123291016, -1450.8819580078),
    vector2(-1481.9425048828, -1518.7020263672),
    vector2(-1353.3962402344, -1724.3046875),
    vector2(-1174.3074951172, -1596.7479248046),
    vector2(-1068.4993896484, -1518.3016357422),
    vector2(-1051.7880859375, -1534.9455566406),
    vector2(-1020.5339355468, -1507.0421142578),
    vector2(-1009.7286376954, -1499.148803711),
    vector2(-994.7778930664, -1518.759399414),
    vector2(-983.17901611328, -1510.3615722656),
    vector2(-975.7451171875, -1523.041015625),
    vector2(-949.15618896484, -1500.26953125),
    vector2(-963.99743652344, -1460.7761230468),
    vector2(-964.91784667968, -1456.5852050782),
    vector2(-961.8667602539, -1455.7337646484),
    vector2(-892.26483154296, -1430.162475586),
    vector2(-909.85125732422, -1382.734008789),
    vector2(-1011.438659668, -1419.935913086),
    vector2(-1016.6520385742, -1407.2468261718),
    vector2(-1006.4899291992, -1368.463256836),
    vector2(-994.21063232422, -1363.2774658204),
    vector2(-992.6928100586, -1360.3028564454),
    vector2(-1007.9810791016, -1333.7833251954),
    vector2(-987.40002441406, -1321.7795410156),
    vector2(-993.81030273438, -1309.904663086),
    vector2(-993.81903076172, -1296.001953125),
    vector2(-1004.842224121, -1278.2258300782),
    vector2(-1026.376586914, -1242.4583740234),
    vector2(-1056.4322509766, -1260.4581298828),
    vector2(-1074.5510253906, -1230.9836425782),
    vector2(-1116.550415039, -1253.4011230468),
    vector2(-1140.3133544922, -1206.879272461),
    vector2(-1153.5633544922, -1209.2806396484)
}, {
    name = "strand",
    --minZ = -0.42107212543488,
    --maxZ = 8.5714092254638
})

local isInRedzonePoly = false
local currentMap = 1
local tijd = 0

---@param playerCoords vector3
function IsSpelerInPolyZone(playerCoords)
    if mapswitch then
        return true
    end

    if currentMap == 1 then
        return rzscrapeyard:isPointInside(playerCoords)
    elseif currentMap == 2 then
        return rzcayoperico:isPointInside(playerCoords)
    elseif currentMap == 3 then
        return rzkortzcenter:isPointInside(playerCoords)
    elseif currentMap == 4 then
        return rzmirrorpark:isPointInside(playerCoords)
    elseif currentMap == 5 then
        return rzhouthakkers:isPointInside(playerCoords)
    elseif currentMap == 6 then
        return rzgrovestreet:isPointInside(playerCoords)
    elseif currentMap == 7 then
        return sandy:isPointInside(playerCoords)
    elseif currentMap == 8 then
        return paleto:isPointInside(playerCoords)
    elseif currentMap == 9 then
        return humanelabs:isPointInside(playerCoords)
    elseif currentMap == 10 then
        return powerplant:isPointInside(playerCoords)
    elseif currentMap == 11 then
        return hotel:isPointInside(playerCoords)
    elseif currentMap == 12 then
        return hb:isPointInside(playerCoords)
    elseif currentMap == 13 then
        return strand:isPointInside(playerCoords)
    end

    return false
end

Citizen.CreateThread(function()
    while true do
        local currentMapData = lib.callback.await('redzone:get:currentmap')

        if currentMapData then
            currentMap = currentMapData.groupIndex
            -- print("Current Map Updated: " .. currentMapData.mapName .. " (Index: " .. currentMap .. ")")
        else
            print("Error: No data received for current red zone map.")
        end

        Citizen.Wait(1000)

        if isinderedzone then
            local playerCoords = GetEntityCoords(PlayerPedId())
            isInRedzonePoly = IsSpelerInPolyZone(playerCoords)

            if isInRedzonePoly then
                tijd = 0
            else
                ESX.ShowNotification('warning', 'Ga terug naar de redzone, anders ga je respawnen!', 3000)

                if tijd == 0 then
                    tijd = GetGameTimer()
                    DebugPrint('Timer gestart.')
                elseif GetGameTimer() - tijd >= 10000 then
                    DebugPrint('Timer is groter of gelijk aan 10 seconden dus respawn je.')
                    DoScreenFadeOut(3000)
                    Citizen.Wait(3000)
                    DebugPrint('Je bent gerespawned.')
                    TeleportNaarRedzone()
                    tijd = 0
                end
            end
        end
    end
end)

function DebugPrint(message)
    print(message)
end



-- extractie
Citizen.CreateThread(function()
    while not ESX.PlayerLoaded do Wait(0) end
    while not isinderedzone do Wait(0) end
    while true do
        local sleep = 500
        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)
        for i, k in pairs(Config.ExtractieLocaties) do
            local escapecoords = vector3(k.x, k.y, k.z)
            local dist = #(coords - escapecoords)
            if dist <= 20.0 and dist > 3.0 then
                sleep = 0
                for i, k in pairs(Config.ExtractieLocaties) do
                    ESX.DrawBasicMarker(k, 0, 74, 154)
                end
            elseif dist < 3.0 then
                sleep = 0
                for i, k in pairs(Config.ExtractieLocaties) do
                    ESX.DrawBasicMarker(k, 0, 74, 154)
                end
                local delay = 10
                ESX.ShowNotification('success', 'Je wordt over ' .. delay .. ' secondes uit de redzone geplaatst.', 3000)
                while delay > 0 do
                    DebugPrint(delay)
                    delay = delay - 1
                    Citizen.Wait(1000)
                    coords = GetEntityCoords(playerPed)
                    dist = #(coords - escapecoords)
                    if dist > 3.0 then
                        ESX.ShowNotification('error',
                            'Je bent te ver weg gelopen en wordt niet meer naar lobby geplaatst', 3000)
                        break
                    end
                    if delay < 5 then
                        DoScreenFadeOut(3000)
                    end
                end
                if dist < 3.0 then
                    TeleportNaarSpawn()
                end
            end
        end
        Wait(sleep)
    end
end)

-- stats
RegisterNetEvent('redzone:get:killcounter')
AddEventHandler('redzone:get:killcounter', function(count)
    playercount = 0
    Wait(1000)
    playercount = count
    DebugPrint('playercount', playercount)
    LoadKillPlayersCounter()
end)

RegisterNetEvent('redzone:get:kills')
AddEventHandler('redzone:get:kills', function(killCount)
    kills = killCount
    GetStats()
    DebugPrint('kills', killCount)
    LoadKillPlayersCounter()
end)

function LoadKillPlayersCounter()
    if isinderedzone then
        SendNUIMessage({
            action = "displaycounter",
            kills = kills,
            players = playercount
        })
    else
        SendNUIMessage({
            action = "hidecounter"
        })
    end
end

function GetRedzoneRank(points)
    local Rank = 'Unranked'
    if points <= 0 then
        Rank = 'Unranked'
    elseif points > 0 and points < 250 then
        Rank = 'Bronze I'
    elseif points > 250 and points < 500 then
        Rank = 'Bronze II'
    elseif points > 500 and points < 1000 then
        Rank = 'Bronze III'
    elseif points > 1000 and points < 1500 then
        Rank = 'Silver I'
    elseif points > 1500 and points < 2000 then
        Rank = 'Silver II'
    elseif points > 2000 and points < 2500 then
        Rank = 'Silver III'
    elseif points > 2500 and points < 3250 then
        Rank = 'Gold I'
    elseif points > 3250 and points < 4000 then
        Rank = 'Gold II'
    elseif points > 4000 and points < 4750 then
        Rank = 'Gold III'
    elseif points > 4750 and points < 4500 then
        Rank = 'Platinum I'
    elseif points > 4500 and points < 5250 then
        Rank = 'Platinum II'
    elseif points > 5250 and points < 6000 then
        Rank = 'Platinum III'
    elseif points > 6000 and points < 7000 then
        Rank = 'Diamond I'
    elseif points > 7000 and points < 8000 then
        Rank = 'Diamond II'
    elseif points > 8000 and points < 9000 then
        Rank = 'Diamond III'
    elseif points > 9000 and points < 10250 then
        Rank = 'Crimson I'
    elseif points > 10250 and points < 11500 then
        Rank = 'Crimson II'
    elseif points > 11500 and points < 12750 then
        Rank = 'Crimson III'
    elseif points > 12750 and points < 14250 then
        Rank = 'Iridescent I'
    elseif points > 14250 and points < 15750 then
        Rank = 'Iridescent II'
    elseif points > 15750 and points < 17250 then
        Rank = 'Iridescent III'
    elseif points > 20000 and points < 50000 then
        Rank = 'Insane'
    elseif points > 50000 and points < 100000 then
        Rank = 'Champion'
    elseif points > 100000 and points < 150000 then
        Rank = 'Legendary'
    end
    return Rank
end

local LoadedStats = false
function GetStats()
    LoadedStats = true
    ESX.TriggerServerCallback('redzone:get:player:stats', function(data)
        AllKills = data.kills
        AllDeaths = data.deaths
        AllHeadshots = data.headshots
        AllPoints = data.points
        AllKD = string.format("%.2f", AllKills / AllDeaths) or 0.0
        Credits = data.credits
        Clan = data.clan
        Rank = GetRedzoneRank(AllPoints)
    end)
end

Citizen.CreateThread(function()
    local sendstats = false
    while true do
        while not isinderedzone do Wait(0) end
        if not LoadedStats then
            GetStats()
        end
        if IsControlJustPressed(0, 20) then
            sendstats = true
        elseif IsControlJustReleased(0, 20) then
            sendstats = false
        end
        if sendstats then
            SendNUIMessage({
                action = "displaystats",
                rank = Rank,
                points = AllPoints,
                kd = AllKD,
                kills = AllKills,
                headshots = AllHeadshots,
                credits = Credits,
                deaths = AllDeaths,
                clan = Clan
            })
        else
            SendNUIMessage({
                action = "hidestats"
            })
        end
        Citizen.Wait(0)
    end
end)

function LoadStats()
    if not LoadedStats then
        GetStats()
    end

    if isdichtbijderedzone then
        SendNUIMessage({
            action = "displaystats",
            rank = Rank,
            points = AllPoints,
            kd = AllKD,
            kills = AllKills,
            headshots = AllHeadshots,
            credits = Credits,
            deaths = AllDeaths,
            clan = Clan
        })
    else
        SendNUIMessage({
            action = "hidestats"
        })
    end
end



-- Function to register a kill
function registerKill(killerId)
    local isInRedZone = isinderedzone() -- Check if the killer is in the red zone
    TriggerServerEvent('redzone:updatePlayerData', killerId, 'kills', isInRedZone)
end

-- Function to register a death
function registerDeath()
    --local isInRedZone = isinderedzone() -- Check if the player is in the red zone
    TriggerServerEvent('redzone:updatePlayerData', GetPlayerServerId(PlayerId()), 'deaths', isInRedZone)
end

-- Detect when the player dies
AddEventHandler('esx:onPlayerDeath', function(killedByPlayer, deathCause)
    registerDeath()
end)

-- Detect when a kill is registered
RegisterNetEvent('redzone:registerKill')
AddEventHandler('redzone:registerKill', function(killerId)
    registerKill(killerId)
end)



TriggerEvent('chat:addSuggestion', '/rzmaperanderen', 'Pas de map aan via een command')

TriggerEvent('chat:addSuggestion', '/rzplayercount', 'Bekijk de playercount in de redzone')
TriggerEvent('chat:addSuggestion', '/rzmap', 'Bekijk de map die actief is ')


TriggerEvent('chat:addSuggestion', '/rzstats', 'Bekijk de stats van een speler', {
    { name = "spelerid", help = "ID van de speler" },
})

-- exports
exports('isloadinginredzone', function()
    return isloadinginredzone
end)

exports('isdichtbijderedzone', function()
    return isdichtbijderedzone
end)

exports('isinderedzone', function()
    return isinderedzone
end)

-- Resource Stop
AddEventHandler('onResourceStop', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then
        return
    end
    if isinderedzone then
        TeleportNaarSpawn()
        DoScreenFadeIn(2000)
        SpawnProt('stop')
    elseif isloadinginredzone then
        DoScreenFadeIn(2000)
    end
end)


-- NUI Menu
function OpenRedzoneMenu()
    SendNUIMessage({
        action = "redzonemenu"
    })
end

-- NUI Callbacks --
RegisterNUICallback('PlayRedzone', function(data, cb)
    EnterRedzone()
    cb('ok')
end)

RegisterNUICallback('close', function(data, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

---comment
---@param coords vector3
function Teleport(coords)
    local obj <close> = defer(function()
        print("NewLoadSceneStop")
        NewLoadSceneStop()
    end)

    LoadCoords(coords, false)
    SetEntityCoords(PlayerPedId(), coords.x, coords.y, coords.z)
end

RegisterNetEvent("redzone:Teleport", function(coords)
    Teleport(coords)
end)

RegisterNUICallback("play", function(data)
    print("Play button pressed!")
end)

local display = false

function ToggleRedzoneUI()
    display = not display
    OpenRedzoneUI(display)
end

RegisterCommand("dashboard", function()
    OpenRedzoneUI()
end)

RegisterNUICallback("exit", function(data)
    OpenRedzoneUI(false)
end)

function OpenRedzoneUI(bool)
    display = bool
    SetNuiFocus(bool, bool)
    SendNUIMessage({
        type = "ui",
        status = bool
    })
end


local playerDied = false

AddEventHandler('esx:onPlayerDeath', function(killedByPlayer, deathCause)
    if exports['redzone']:isinderedzone() then -- Check if the player is in the red zone
        local playerPed = PlayerPedId()

        if IsEntityDead(playerPed) and not playerDied then
            playerDied = true
            local killer = GetPedSourceOfDeath(playerPed)
            local killerId = nil

            -- Check if the killer is a player
            if killer ~= 0 and IsPedAPlayer(killer) then
                killerId = GetPlayerServerId(NetworkGetPlayerIndexFromPed(killer))
            end

            -- Trigger the server event with necessary data
            TriggerServerEvent('esx:onPlayerDeath', {
                victim = GetPlayerServerId(PlayerId()),
                killer = killerId or nil,
                cause = deathCause or nil,
                isinderedzone = true -- Indicate that the death occurred in the red zone
            })
        end
    end
end)

-- Reset death state when the player respawns
AddEventHandler('playerSpawned', function()
    playerDied = false
end)


-- Kill message when a player dies
AddEventHandler('baseevents:onPlayerDied', function(killerType, deathCoords)
    local playerPed = PlayerPedId()
    local playerName = GetPlayerName(PlayerId())

    if isinderedzone then
        TriggerEvent('chatMessage', 'Redzone', "adminchat", playerName .. ' heeft zelfmoord gepleegd')
    end
end)

AddEventHandler("baseevents:onPlayerKilled", function(player, killer, reason, pos)
    local playerName = GetPlayerName(player)
    local killerName = GetPlayerName(killer)

    print("Player killed event triggered")
    print("isinderedzone:", isinderedzone)

    if isinderedzone then
        print("Chat message: " .. playerName .. ' is gekilled door ' .. killerName)

        TriggerEvent('chat:addMessage', {
            color = { 255, 0, 0 },
            multiline = true,
            args = {"Redzone", playerName .. ' is gekilled door ' .. killerName}
        })
    end
end)





