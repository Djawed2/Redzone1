RegisterNetEvent('redzone:geefwapen')
AddEventHandler('redzone:geefwapen', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    if xPlayer then
        -- local allRoles = exports["discordperms"]:GetPlayerRoles()

        print(json.encode(allRoles))


        -- local hasBestuur = allRoles["bestuur"] or false
        -- local hasSupporterPlus = allRoles["supporterplus"] or false
        -- local hasSupporter = allRoles["supporter"] or false
        local selectedWeapon
        local randomChance = math.random(100)
        print("Random chance rolled: " .. tostring(randomChance))

        local totalChance = 0
        for weaponName, weaponData in pairs(Config.Loadouts) do
            local chance = weaponData.chance

            if hasBestuur then
                chance = weaponData.bestuurchance
            elseif hasSupporterPlus then
                chance = weaponData.supporterpluschance
            elseif hasSupporter then
                chance = weaponData.supporterchance
            end

            totalChance = totalChance + chance
            if randomChance <= totalChance then
                selectedWeapon = weaponName
                break
            end
        end

        if not selectedWeapon then
            selectedWeapon = next(Config.Loadouts)
            print("No specific weapon selected. Defaulting to: " .. tostring(selectedWeapon))
        end

        local randomWeapon = Config.Loadouts[selectedWeapon]

        print("Selected weapon: " .. tostring(selectedWeapon))

        xPlayer.addInventoryItem(selectedWeapon, 1)       
        xPlayer.addInventoryItem(randomWeapon.ammo, 250)    
        
        for _, randomItem in ipairs(randomWeapon.randomitems) do
            xPlayer.addInventoryItem(randomItem, 1)
            print("Added random item: " .. tostring(randomItem))
        end
        
        print("Random weapon data: " .. json.encode(randomWeapon))

        local playerPed = GetPlayerPed(-1)
        
        local currentWeaponHash = GetSelectedPedWeapon(playerPed)

        local randomComponentGroup = randomWeapon.components
        if randomComponentGroup and #randomComponentGroup > 0 then
            local component = randomComponentGroup[math.random(#randomComponentGroup)]
            print("Selected component: ", json.encode(component))

            if component then
                GiveWeaponComponentToPed(playerPed, currentWeaponHash, component)
                print("Given component: " .. tostring(component))
            else
                print("No valid component found.")
            end
        else
            print("No components available for this weapon.")
        end
    end
end)
