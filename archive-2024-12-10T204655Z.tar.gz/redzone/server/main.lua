ESX = exports["es_extended"]:getSharedObject()

ESX = nil 

TriggerEvent('esx:getSharedObject', function(obj) 
    ESX = obj 
end)

local redzoneRoutingBucket = 6969

RegisterNetEvent('checkRedzoneStatus')
AddEventHandler('checkRedzoneStatus', function(coord)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    local playerBucket = GetPlayerRoutingBucket(xPlayer.source)

    if playerBucket == redzoneRoutingBucket then
        local isInRedzone = Redzoneblock:isPointInside(coord)
        TriggerClientEvent('updateRedzoneStatus', _source, true, isInRedzone)
    else
        TriggerClientEvent('updateRedzoneStatus', _source, false, false)
    end
end)


RegisterNetEvent('redzone:spawnbasicneeds')
AddEventHandler('redzone:spawnbasicneeds', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    if xPlayer then
        xPlayer.addInventoryItem("stim", 1) 
        xPlayer.addInventoryItem("gps", 1)
        xPlayer.addInventoryItem("amor", 1)
    end
end)


RegisterServerEvent("saveloadout")
AddEventHandler("saveloadout", function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer then
        local playerLoadout = xPlayer.getLoadout()
        local playerInventory = xPlayer.getInventory()

        for _, v in pairs(playerLoadout) do
            if not ox_inventory[v.name] then
                ox_inventory[v.name] = { ammo = v.ammo }
            else
                ox_inventory[v.name].ammo = v.ammo
            end
        end

        for _, v in pairs(playerInventory) do
            xPlayer.removeInventoryItem(v.name, v.count)
        end
    end
end)

RegisterServerEvent("clearinv")
AddEventHandler("clearinv", function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer then
        local playerLoadout = xPlayer.getLoadout()
        local playerInventory = xPlayer.getInventory()

        for _, v in pairs(playerLoadout) do
            if not ox_inventory[v.name] then
                ox_inventory[v.name] = { ammo = v.ammo }
            else
                ox_inventory[v.name].ammo = v.ammo
            end
        end

        for _, v in pairs(playerInventory) do
            xPlayer.removeInventoryItem(v.name, v.count)
        end
    end
end)

RegisterServerEvent("redzone:leave")
AddEventHandler("redzone:leave", function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer then
        exports.ox_inventory:ClearInventory(source)
        TriggerEvent('lrp-ambulance:client:revive:player')     
        SetPlayerRoutingBucket(source, 0)
        local playerInventory = xPlayer.getInventory()
        for _, item in pairs(playerInventory) do
            xPlayer.removeInventoryItem(item.name, item.count)
        end
    end
end)

RegisterServerEvent("restoreloadout")
AddEventHandler("restoreloadout", function(loadout)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)

    if xPlayer then
        exports.ox_inventory:ClearInventory(_source)

        for _, v in pairs(loadout) do
            local weaponName = v.name
            local ammoCount = v.ammo
            xPlayer.addWeapon(weaponName, ammoCount)
        end
    end
end)

local currentRedzoneGroupIndex = nil
local currentRedzoneLocation = nil
local currentMapId = 1

function changeRedzoneLocation()
    if not Config or not Config.SpawnLocaties or not Config.MapLabels then
        print("Error: Config or required fields are missing.")
        return
    end

    currentRedzoneGroupIndex = math.random(1, #Config.SpawnLocaties)
    local selectedGroup = Config.SpawnLocaties[currentRedzoneGroupIndex]

    if not selectedGroup or #selectedGroup == 0 then
        print("Error: No valid spawn locations found in the selected group.")
        return
    end

    currentRedzoneLocation = selectedGroup[math.random(1, #selectedGroup)]
    
    if not currentRedzoneLocation or not currentRedzoneLocation.x or not currentRedzoneLocation.y or not currentRedzoneLocation.z then
        print("Error: Invalid redzone location coordinates.")
        return
    end

    local redzoneName = Config.MapLabels[currentRedzoneGroupIndex] or "Onbekend"   
    currentMapId = currentRedzoneGroupIndex

    TriggerClientEvent('redzone:switch:to:newmap', -1, currentMapId)
end


CreateThread(function()
    while true do
        changeRedzoneLocation()
        Wait(1800000)  -- Change location every 30 minutes
    end
end)

RegisterNetEvent("redzone:join")
AddEventHandler("redzone:join", function()
    local playerId = source
    local xPlayer = ESX.GetPlayerFromId(playerId)

    if xPlayer then
        if currentRedzoneGroupIndex and currentRedzoneLocation then
            local selectedGroup = Config.SpawnLocaties[currentRedzoneGroupIndex]
            local randomLocation = selectedGroup[math.random(1, #selectedGroup)]
            
            -- Teleport the player to the selected red zone location
            SetEntityCoords(GetPlayerPed(playerId), randomLocation.x, randomLocation.y, randomLocation.z, false, false, false, true)
            
            -- Check if the teleportation was successful
            if IsEntityAtCoord(GetPlayerPed(playerId), randomLocation.x, randomLocation.y, randomLocation.z, 1.0, 1.0, 1.0, false, true, 0) then
                TriggerEvent('setPlayerRoutingBucket', playerId, redzoneRoutingBucket)
                TriggerEvent('lrp-case:join', redzoneRoutingBucket)

                print("Speler is in de redzone geteleporteert naar: " .. json.encode(randomLocation))
            else
                print("Teleporteren naar redzone is mislukt voor speler met ID: " .. playerId)
            end
        else
            print("Er is geen actieve redzone-groep of locatie om naar te teleporteren.")
        end
    else
        print("Speler niet gevonden voor redzone:tp event.")
    end
end)

lib.callback.register('redzone:get:currentmap', function(source)
    local currentMapName = Config.MapLabels[currentRedzoneGroupIndex] or "Onbekend"
    return {
        groupIndex = currentRedzoneGroupIndex,
        location = currentRedzoneLocation,
        mapName = currentMapName,
        coordinates = {
            x = currentRedzoneLocation and currentRedzoneLocation.x or nil,
            y = currentRedzoneLocation and currentRedzoneLocation.y or nil,
            z = currentRedzoneLocation and currentRedzoneLocation.z or nil
        }
    }
end)

RegisterCommand("rzmaperanderen", function(source)
    if IsPlayerGroupAdmin(source) then
        changeRedzoneLocation()
    else
        TriggerClientEvent('chat:addMessage', source, {
            args = { "[SYSTEEM]", "Je hebt geen permissies hiervoor" },
            color = { 255, 0, 0 }
        })
    end
end, false)

RegisterCommand("rzmap", function(source)
    if currentRedzoneGroupIndex then
        local groupName = Config.MapLabels[currentRedzoneGroupIndex] or "Onbekend"
        TriggerClientEvent('chat:addMessage', source, {
            args = { "[Redzone]", "De huidige redzone is in " .. groupName },
            color = { 255, 0, 0 }
        })
    else
        TriggerClientEvent('chat:addMessage', source, {
            args = { "[Redzone]", "Er is momenteel geen actieve redzone." },
            color = { 255, 0, 0 }
        })
    end
end, false)

function IsPlayerGroupAdmin(playerId)
    local xPlayer = ESX.GetPlayerFromId(playerId)
    return xPlayer and xPlayer.getGroup() == 'admin'
end

RegisterNetEvent("redzone:playerHit", function()
    local source = source
    TriggerClientEvent("redzone:hitmarker", source)
end)

ESX.RegisterServerCallback('redzone:set:wereld', function(source, cb, world)
    local routingBucketID = (world == 'redzone') and Config.RedzoneRoutingBucketID or 0

    SetPlayerRoutingBucket(source, routingBucketID)

    if routingBucketID > 0 then
        print("Player " .. GetPlayerName(source) .. " is set to redzone.")
    else
        print("Player " .. GetPlayerName(source) .. " is set to spawn.")
    end

    cb(true)
end)

RegisterNetEvent('inredzonewereld')
AddEventHandler('inredzonewereld', function()
    SetPlayerRoutingBucket(6969)
    print("Speler " .. GetPlayerName(source) .. " in redzone.")    
end)

RegisterNetEvent('uitredzonewereld')
AddEventHandler('uitredzonewereld', function()
    SetPlayerRoutingBucket(0)
    print("Speler " .. GetPlayerName(source) .. " uit redzone.")
end)

local function getRank(points)
    if points <= 0 then return 'Unranked' end
    if points < 250 then return 'Bronze I' end
    if points < 500 then return 'Bronze II' end
    if points < 1000 then return 'Bronze III' end
    if points < 1500 then return 'Silver I' end
    if points < 2000 then return 'Silver II' end
    if points < 2500 then return 'Silver III' end
    if points < 3250 then return 'Gold I' end
    if points < 4000 then return 'Gold II' end
    if points < 4750 then return 'Gold III' end
    if points < 4500 then return 'Platinum I' end
    if points < 5250 then return 'Platinum II' end
    if points < 6000 then return 'Platinum III' end
    if points < 7000 then return 'Diamond I' end
    if points < 8000 then return 'Diamond II' end
    if points < 9000 then return 'Diamond III' end
    if points < 10250 then return 'Crimson I' end
    if points < 11500 then return 'Crimson II' end
    if points < 12750 then return 'Crimson III' end
    if points < 14250 then return 'Iridescent I' end
    if points < 15750 then return 'Iridescent II' end
    if points < 17250 then return 'Iridescent III' end
    if points < 50000 then return 'Insane' end
    if points < 100000 then return 'Champion' end
    return 'Legendary'
end

local function initializePlayerStats(identifier)
    MySQL.Async.execute('INSERT INTO user_stats (identifier, kills, deaths, headshots, points, credits) VALUES (@identifier, 0, 0, 0, 0, 0)', {
        ['@identifier'] = identifier
    }, function(rowsChanged)
        if rowsChanged > 0 then
            print("Initialized stats for identifier: " .. identifier)
        else
            print("Failed to initialize stats for identifier: " .. identifier)
        end
    end)
end

ESX.RegisterServerCallback('redzone:get:player:stats', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then
        cb(nil)
        return
    end

    local identifier = xPlayer.identifier or (xPlayer.getIdentifier and xPlayer.getIdentifier())
    if not identifier then
        cb(nil)
        return
    end

    MySQL.Async.fetchAll('SELECT * FROM user_stats WHERE identifier = @identifier', {
        ['@identifier'] = identifier
    }, function(result)
        if result and result[1] then
            cb({
                kills = result[1].kills,
                deaths = result[1].deaths,
                headshots = result[1].headshots,
                points = result[1].points,
                credits = result[1].credits,
                rank = getRank(result[1].points)
            })
        else
            initializePlayerStats(identifier)
            cb({
                kills = 0,
                deaths = 0,
                headshots = 0,
                points = 0,
                credits = 0,
                rank = 'Unranked'
            })
        end
    end)
end)


local function updatePlayerData(playerId, dataType)
    local xPlayer = ESX.GetPlayerFromId(playerId)
    if xPlayer then
        local identifier = xPlayer.identifier

        if dataType == 'kills' then
            MySQL.Async.execute('UPDATE user_stats SET kills = kills + 1, points = points + 10 WHERE identifier = @identifier', {
                ['@identifier'] = identifier
            }, function(rowsChanged)
                if rowsChanged > 0 then
                    --TriggerClientEvent('esx:showNotification', playerId, "success", "Je hebt iemand vermoord! (+10 punten)")
                else
                    print("Failed to update kills for player: " .. identifier)
                end
            end)
        elseif dataType == 'deaths' then
            MySQL.Async.execute('UPDATE user_stats SET deaths = deaths + 1, points = points - 5 WHERE identifier = @identifier', {
                ['@identifier'] = identifier
            }, function(rowsChanged)
                if rowsChanged > 0 then
                    --TriggerClientEvent('esx:showNotification', playerId, "error", "Je bent dood! (-5 punten)")
                else
                    print("Failed to update deaths for player: " .. identifier)
                end
            end)
        end
    end
end

RegisterNetEvent('redzone:registerKill')
AddEventHandler('redzone:registerKill', function(attackerId)
    local xPlayer = ESX.GetPlayerFromId(attackerId)

    if xPlayer then
        updatePlayerData(attackerId, 'kills')
    else
        print("Attacker not found with ID: " .. attackerId)
    end
end)

RegisterNetEvent('redzone:playerDied')
AddEventHandler('redzone:playerDied', function(killerId)
    local playerId = source
    local xPlayer = ESX.GetPlayerFromId(playerId)

    if xPlayer then
        updatePlayerData(playerId, 'deaths')

        if killerId then
            local killerPlayer = ESX.GetPlayerFromId(killerId)
            if killerPlayer then
                TriggerEvent('redzone:registerKill', killerId)

               -- TriggerClientEvent('esx:showNotification', killerId, "success", "Je hebt " .. xPlayer.getName() .. " vermoord!")

                TriggerClientEvent('chat:addMessage', -1, {
                    args = {"Red Zone", xPlayer.getName() .. " is vermoord door " .. killerPlayer.getName() .. "!"}
                })
            else
                print("Killer player not found: ID " .. killerId)
            end
        end

        TriggerClientEvent('esx:onPlayerDeath', playerId, {
            killedByPlayer = killerId ~= nil,
            killerServerId = killerId
        })
    else
        print("Victim player not found: ID " .. playerId)
    end
end)

RegisterServerEvent('esx:onPlayerDeath')
AddEventHandler('esx:onPlayerDeath', function(data)
    local victim = source

    if data and victim then
        updatePlayerData(victim, 'deaths')
        if data.killedByPlayer then
            local killerId = data.killerServerId
            if killerId then
                updatePlayerData(killerId, 'kills')
                local killerName = GetPlayerName(killerId)
                local victimName = GetPlayerName(victim)
            end
        end
    else
        print("Error: Couldn't register player's death")
    end
end)

RegisterCommand("rzstats", function(source, args, rawCommand)
    local targetId = args[1] and tonumber(args[1]) or source
    local xPlayer = ESX.GetPlayerFromId(targetId)

    if xPlayer then
        local identifier = xPlayer.identifier
        MySQL.Async.fetchAll('SELECT * FROM user_stats WHERE identifier = @identifier', {
            ['@identifier'] = identifier
        }, function(result)
            if result[1] then
                local points = result[1].points
                local rank = getRank(points)

                TriggerClientEvent('chat:addMessage', source, {
                    args = {"Statistieken van " .. GetPlayerName(targetId) .. ": Kills: " .. result[1].kills .. 
                        ", Deaths: " .. result[1].deaths ..
                        ", Points: " .. points ..
                        ", Rank: " .. rank
                    }
                })
            end
        end)
    end
end, false)

AddEventHandler('playerDropped', function(reason)
    local playerId = source
    local xPlayer = ESX.GetPlayerFromId(playerId)

    if xPlayer then
        local identifier = xPlayer.identifier
        MySQL.Async.fetchAll('SELECT * FROM user_stats WHERE identifier = @identifier', {
            ['@identifier'] = identifier
        }, function(result)
            if result[1] then
                TriggerClientEvent('redzone:updatePlayerStats', playerId, {
                    kills = result[1].kills,
                    deaths = result[1].deaths,
                    headshots = result[1].headshots,
                    points = result[1].points,
                    credits = result[1].credits,
                    rank = getRank(result[1].points)
                })
            else
                initializePlayerStats(identifier)
            end
        end)
    end
end)