local weaponsOnly = false
ESX = exports["es_extended"]:getSharedObject()

RegisterServerEvent('esx:onPlayerDeath')
AddEventHandler('esx:onPlayerDeath', function(data)
    if data.isinderedzone then
        local victim = source
        local xPlayer = ESX.GetPlayerFromId(victim)
        local rawInventory = exports.ox_inventory:Inventory(victim).items
        local inventory = {}

        if weaponsOnly then
            for _, v in pairs(rawInventory) do
                if v.name:sub(0, 7) == 'WEAPON_' then
                    inventory[#inventory + 1] = {
                        v.name,
                        v.count,
                        v.metadata
                    }
                    exports.ox_inventory:RemoveItem(victim, v.name, v.count, v.metadata)
                end
            end
        else
            for _, v in pairs(rawInventory) do
                inventory[#inventory + 1] = {
                    v.name,
                    v.count,
                    v.metadata
                }
            end
        end

        local deathCoords = xPlayer.getCoords(true)

        if #inventory > 0 then
            exports.ox_inventory:CustomDrop('Redzone Drop', inventory, deathCoords)
        end

        if not weaponsOnly then
            exports.ox_inventory:ClearInventory(victim, false)
        end

        if data.killer then
            local killer = ESX.GetPlayerFromId(data.killer)
            if killer then
                print(("[INFO] Player %s killed %s in the red zone"):format(killer.getName(), xPlayer.getName()))
            end
        end
    end
end)
